/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mi.casita.segura;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author sazo
 */

public class MantenimientoUsuariosGUI extends JFrame {
    private UsuarioService usuarioService;
    private DefaultTableModel tableModel;
    private JTable usuariosTable;
    private JButton btnCrearUsuario;

    // Componentes del formulario de creación
    private JDialog dialogCrearUsuario;
    private JTextField txtDPI, txtNombre, txtApellidos, txtCorreo;
    private JPasswordField txtContrasena;
    private JComboBox<Rol> cmbRol;
    private JComboBox<String> cmbLote, cmbNumeroCasa;
    private JButton btnGuardar, btnLimpiar, btnCancelar;

    public MantenimientoUsuariosGUI() {
        usuarioService = new UsuarioService();
        initializeComponents();
        cargarUsuarios();
    }

    private void initializeComponents() {
        setTitle("Mantenimiento de Usuarios - Mi Casita Segura");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel principal
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Panel superior con botón
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnCrearUsuario = new JButton("Crear Usuario");
        btnCrearUsuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarDialogoCrearUsuario();
            }
        });
        topPanel.add(btnCrearUsuario);

        // Tabla de usuarios
        String[] columnNames = {"DPI", "Nombre", "Apellidos", "Correo", "Número de Casa", "Rol", "Eliminar"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 6; // Solo la columna de eliminar es editable
            }
        };
        
        usuariosTable = new JTable(tableModel);
        usuariosTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        usuariosTable.setRowHeight(25);
        
        // Agregar botón de eliminar a cada fila
        usuariosTable.getColumn("Eliminar").setCellRenderer(new ButtonRenderer());
        usuariosTable.getColumn("Eliminar").setCellEditor(new ButtonEditor(new JCheckBox()));

        JScrollPane scrollPane = new JScrollPane(usuariosTable);
        scrollPane.setPreferredSize(new Dimension(800, 400));

        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);
        pack();
        setLocationRelativeTo(null);

        // Inicializar diálogo de creación
        inicializarDialogoCrearUsuario();
    }

    private void inicializarDialogoCrearUsuario() {
        dialogCrearUsuario = new JDialog(this, "Crear Usuario", true);
        dialogCrearUsuario.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // Campos del formulario
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.EAST;
        dialogCrearUsuario.add(new JLabel("DPI del residente:"), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST; gbc.fill = GridBagConstraints.HORIZONTAL;
        txtDPI = new JTextField(15);
        dialogCrearUsuario.add(txtDPI, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.anchor = GridBagConstraints.EAST; gbc.fill = GridBagConstraints.NONE;
        dialogCrearUsuario.add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST; gbc.fill = GridBagConstraints.HORIZONTAL;
        txtNombre = new JTextField(15);
        dialogCrearUsuario.add(txtNombre, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.anchor = GridBagConstraints.EAST; gbc.fill = GridBagConstraints.NONE;
        dialogCrearUsuario.add(new JLabel("Apellidos:"), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST; gbc.fill = GridBagConstraints.HORIZONTAL;
        txtApellidos = new JTextField(15);
        dialogCrearUsuario.add(txtApellidos, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.anchor = GridBagConstraints.EAST; gbc.fill = GridBagConstraints.NONE;
        dialogCrearUsuario.add(new JLabel("Correo:"), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST; gbc.fill = GridBagConstraints.HORIZONTAL;
        txtCorreo = new JTextField(15);
        dialogCrearUsuario.add(txtCorreo, gbc);

        gbc.gridx = 0; gbc.gridy = 4; gbc.anchor = GridBagConstraints.EAST; gbc.fill = GridBagConstraints.NONE;
        dialogCrearUsuario.add(new JLabel("Contraseña:"), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST; gbc.fill = GridBagConstraints.HORIZONTAL;
        txtContrasena = new JPasswordField(15);
        dialogCrearUsuario.add(txtContrasena, gbc);

        gbc.gridx = 0; gbc.gridy = 5; gbc.anchor = GridBagConstraints.EAST; gbc.fill = GridBagConstraints.NONE;
        dialogCrearUsuario.add(new JLabel("Rol del usuario:"), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST; gbc.fill = GridBagConstraints.HORIZONTAL;
        cmbRol = new JComboBox<Rol>();
        cargarRoles();
        cmbRol.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                toggleCamposCasa();
            }
        });
        dialogCrearUsuario.add(cmbRol, gbc);

        gbc.gridx = 0; gbc.gridy = 6; gbc.anchor = GridBagConstraints.EAST; gbc.fill = GridBagConstraints.NONE;
        dialogCrearUsuario.add(new JLabel("Lote:"), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST; gbc.fill = GridBagConstraints.HORIZONTAL;
        cmbLote = new JComboBox<String>();
        for (char c = 'A'; c <= 'Z'; c++) {
            cmbLote.addItem(String.valueOf(c));
        }
        dialogCrearUsuario.add(cmbLote, gbc);

        gbc.gridx = 0; gbc.gridy = 7; gbc.anchor = GridBagConstraints.EAST; gbc.fill = GridBagConstraints.NONE;
        dialogCrearUsuario.add(new JLabel("Número de casa:"), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST; gbc.fill = GridBagConstraints.HORIZONTAL;
        cmbNumeroCasa = new JComboBox<String>();
        for (int i = 1; i <= 50; i++) {
            cmbNumeroCasa.addItem(String.valueOf(i));
        }
        dialogCrearUsuario.add(cmbNumeroCasa, gbc);

        // Botones
        JPanel buttonPanel = new JPanel(new FlowLayout());
        btnGuardar = new JButton("Guardar usuario");
        btnGuardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarUsuario();
            }
        });
        
        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limpiarFormulario();
            }
        });
        
        btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialogCrearUsuario.setVisible(false);
            }
        });

        buttonPanel.add(btnGuardar);
        buttonPanel.add(btnLimpiar);
        buttonPanel.add(btnCancelar);

        gbc.gridx = 0; gbc.gridy = 8; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        dialogCrearUsuario.add(buttonPanel, gbc);

        dialogCrearUsuario.pack();
        dialogCrearUsuario.setLocationRelativeTo(this);

        // Inicialmente deshabilitar campos de casa
        toggleCamposCasa();
    }

    private void cargarRoles() {
        try {
            List<Rol> roles = usuarioService.obtenerRoles();
            cmbRol.removeAllItems();
            for (Rol rol : roles) {
                cmbRol.addItem(rol);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error cargando roles: " + e.getMessage(), 
                                        "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void toggleCamposCasa() {
        // RN1: Solo habilitar campos si es residente
        Rol rolSeleccionado = (Rol) cmbRol.getSelectedItem();
        boolean esResidente = rolSeleccionado != null && 
                             "Residente".equals(rolSeleccionado.getNombreRol());
        
        cmbLote.setEnabled(esResidente);
        cmbNumeroCasa.setEnabled(esResidente);
        
        if (!esResidente) {
            cmbLote.setSelectedIndex(0);
            cmbNumeroCasa.setSelectedIndex(0);
        }
    }

    private void mostrarDialogoCrearUsuario() {
        limpiarFormulario();
        dialogCrearUsuario.setVisible(true);
    }

    private void guardarUsuario() {
        try {
            // RN2: Validar que todos los campos estén llenos
            if (!validarCamposLlenos()) {
                return;
            }

            // Crear objeto usuario
            Usuario usuario = new Usuario();
            usuario.setDpi(txtDPI.getText().trim());
            usuario.setNombre(txtNombre.getText().trim());
            usuario.setApellidos(txtApellidos.getText().trim());
            usuario.setCorreo(txtCorreo.getText().trim());
            usuario.setContrasena(new String(txtContrasena.getPassword()));
            
            Rol rolSeleccionado = (Rol) cmbRol.getSelectedItem();
            usuario.setIdRol(rolSeleccionado.getIdRol());
            
            // Solo asignar lote y casa si es residente
            if ("Residente".equals(rolSeleccionado.getNombreRol())) {
                usuario.setLote((String) cmbLote.getSelectedItem());
                usuario.setNumeroCasa(Integer.parseInt((String) cmbNumeroCasa.getSelectedItem()));
            }

            // Guardar usuario
            boolean creado = usuarioService.crearUsuario(usuario);
            
            if (creado) {
                JOptionPane.showMessageDialog(this, "Usuario creado correctamente", 
                                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                dialogCrearUsuario.setVisible(false);
                cargarUsuarios(); // Recargar tabla
            } else {
                JOptionPane.showMessageDialog(this, "Error al crear usuario", 
                                            "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), 
                                        "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean validarCamposLlenos() {
        if (txtDPI.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El DPI es obligatorio", 
                                        "Validación", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        
        if (txtNombre.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El nombre es obligatorio", 
                                        "Validación", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        
        if (txtApellidos.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Los apellidos son obligatorios", 
                                        "Validación", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        
        if (txtCorreo.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El correo es obligatorio", 
                                        "Validación", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        
        if (txtContrasena.getPassword().length == 0) {
            JOptionPane.showMessageDialog(this, "La contraseña es obligatoria", 
                                        "Validación", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        
        if (cmbRol.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar un rol", 
                                        "Validación", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        return true;
    }

    private void limpiarFormulario() {
        txtDPI.setText("");
        txtNombre.setText("");
        txtApellidos.setText("");
        txtCorreo.setText("");
        txtContrasena.setText("");
        if (cmbRol.getItemCount() > 0) {
            cmbRol.setSelectedIndex(0);
        }
        cmbLote.setSelectedIndex(0);
        cmbNumeroCasa.setSelectedIndex(0);
        toggleCamposCasa();
    }

    private void cargarUsuarios() {
        try {
            List<Usuario> usuarios = usuarioService.obtenerUsuariosActivos();
            tableModel.setRowCount(0); // Limpiar tabla

            for (Usuario usuario : usuarios) {
                Object[] row = {
                    usuario.getDpi(),
                    usuario.getNombre(),
                    usuario.getApellidos(),
                    usuario.getCorreo(),
                    usuario.getCasaCompleta(),
                    usuario.getNombreRol() != null ? usuario.getNombreRol() : "Sin Rol",
                    "Eliminar"
                };
                tableModel.addRow(row);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error cargando usuarios: " + e.getMessage(), 
                                        "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarUsuario(int row) {
        int confirm = JOptionPane.showConfirmDialog(this, 
            "¿Está seguro de eliminar el usuario?", 
            "Confirmar eliminación", 
            JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                // Obtener el DPI del usuario para encontrar su ID
                String dpi = (String) tableModel.getValueAt(row, 0);
                
                // Obtener usuarios para encontrar el ID correcto
                List<Usuario> usuarios = usuarioService.obtenerUsuariosActivos();
                Usuario usuarioAEliminar = null;
                
                for (Usuario u : usuarios) {
                    if (dpi.equals(u.getDpi())) {
                        usuarioAEliminar = u;
                        break;
                    }
                }
                
                if (usuarioAEliminar != null) {
                    boolean eliminado = usuarioService.eliminarUsuario(usuarioAEliminar.getIdUsuario());
                    
                    if (eliminado) {
                        JOptionPane.showMessageDialog(this, "Usuario eliminado correctamente", 
                                                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
                        cargarUsuarios();
                    } else {
                        JOptionPane.showMessageDialog(this, "Error al eliminar usuario", 
                                                    "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "No se pudo encontrar el usuario", 
                                                "Error", JOptionPane.ERROR_MESSAGE);
                }

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error eliminando usuario: " + e.getMessage(), 
                                            "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Clases auxiliares para botones en tabla
    class ButtonRenderer extends JButton implements javax.swing.table.TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            setText("Eliminar");
            return this;
        }
    }

    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private boolean clicked;
        private int currentRow;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    clicked = true;
                    eliminarUsuario(currentRow);
                    fireEditingStopped();
                }
            });
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean isSelected, int row, int column) {
            currentRow = row;
            button.setText("Eliminar");
            clicked = false;
            return button;
        }

        @Override
        public Object getCellEditorValue() {
            return "Eliminar";
        }
    }

    // Método main para ejecutar la aplicación
    public static void main(String[] args) {
        try {
            // Configurar Look and Feel
            // UIManager.setLookAndFeel(UIManager.getSystemLookAndFeel());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MantenimientoUsuariosGUI().setVisible(true);
            }
        });
    }
}