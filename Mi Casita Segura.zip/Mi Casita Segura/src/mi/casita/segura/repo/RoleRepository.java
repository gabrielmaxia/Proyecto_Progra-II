/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mi.casita.segura.repo;

import java.sql.Connection;
import mi.casita.segura.BDConexion;
import mi.casita.segura.modelo.Role;

/**
 *
 * @author sazo
 */
public class RoleRepository {
    
        private final Connection connection;
        
        public RoleRepository(){
            this.connection = BDConexion.getConnection();
        }
        
        
        public void guardarRole(Role role){
            //
        }
    
}
