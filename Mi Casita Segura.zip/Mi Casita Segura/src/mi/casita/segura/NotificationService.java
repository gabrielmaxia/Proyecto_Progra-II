/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mi.casita.segura;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author sazo
 */

public class NotificationService {
    
    private static final String LOG_FILE = "notificaciones.log";
    
    public void enviarNotificacionAccesoCreado(Usuario usuario) {
        try {
            // Registrar en consola
            enviarNotificacionConsola(usuario);
            
            // Registrar en archivo de log
            registrarEnArchivo(usuario);
            
            // Aquí podrías integrar con servicios como SendGrid, AWS SES, etc.
            // enviarConSendGrid(usuario);
            
        } catch (Exception e) {
            System.err.println("Error enviando notificación: " + e.getMessage());
        }
    }
    
    private void printSingleLine(int iqualsSign, String n){
        for (int i = 0; i < iqualsSign; i++) {
            System.out.print(n);
        }
        System.out.println("\n");
    }

    private void enviarNotificacionConsola(Usuario usuario) {
        String contenido = construirContenidoMensaje(usuario);
        
        printSingleLine(50,"=");
        System.out.println("       NOTIFICACIÓN DE USUARIO CREADO");
         printSingleLine(50,"=");
        System.out.println("Para: " + usuario.getCorreo());
        System.out.println("Asunto: Notificación de accesos creados - Mi Casita Segura");
         printSingleLine(50,"=");
        System.out.println(contenido);
         printSingleLine(50,"=");
        System.out.println("Notificación procesada exitosamente");
        System.out.println("Fecha/Hora: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")));
         printSingleLine(50,"=");
    }

    private void registrarEnArchivo(Usuario usuario) {
        try (FileWriter writer = new FileWriter(LOG_FILE, true)) {
            writer.write("\n" + repetirCaracter('=', 80) + "\n");
            writer.write("NOTIFICACIÓN DE USUARIO CREADO\n");
            writer.write("Fecha: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")) + "\n");
            writer.write(repetirCaracter('-', 80) + "\n");
            writer.write("Usuario: " + usuario.getNombreCompleto() + "\n");
            writer.write("Email: " + usuario.getCorreo() + "\n");
            writer.write("DPI: " + usuario.getDpi() + "\n");
            writer.write("Rol: " + usuario.getNombreRol() + "\n");
            if (usuario.getLote() != null && usuario.getNumeroCasa() != null) {
                writer.write("Casa: " + usuario.getCasaCompleta() + "\n");
            }
            writer.write("Código QR: " + (usuario.getCodigoQr() != null ? usuario.getCodigoQr() : "No generado") + "\n");
            writer.write("Estado: Usuario creado exitosamente\n");
            writer.write(repetirCaracter('=', 80) + "\n");
            
            System.out.println("Notificación registrada en archivo: " + LOG_FILE);
            
        } catch (IOException e) {
            System.err.println("Error escribiendo archivo de log: " + e.getMessage());
        }
    }

    private String construirContenidoMensaje(Usuario usuario) {
        StringBuilder contenido = new StringBuilder();
        contenido.append("¡Hola ").append(usuario.getNombreCompleto()).append("!\n\n");
        contenido.append("Se ha generado exitosamente tu código QR de acceso al residencial. ");
        contenido.append("A continuación, encontrarás los detalles de tu registro:\n\n");
        contenido.append("Nombre del Residente: ").append(usuario.getNombreCompleto()).append("\n");
        contenido.append("DPI: ").append(usuario.getDpi()).append("\n");
        contenido.append("Rol: ").append(usuario.getNombreRol()).append("\n");
        
        if (usuario.getLote() != null && usuario.getNumeroCasa() != null) {
            contenido.append("Casa: ").append(usuario.getCasaCompleta()).append("\n");
        }
        
        contenido.append("Validez del código QR: Permanente\n\n");
        contenido.append("Instrucciones importantes:\n");
        contenido.append("• Guarda este correo o el código QR adjunto.\n");
        contenido.append("• Preséntalo al llegar al residencial para que el personal de seguridad ");
        contenido.append("lo escanee y valide tu acceso.\n\n");
        
        if (usuario.getCodigoQr() != null) {
            contenido.append("Código QR: ").append(usuario.getCodigoQr()).append("\n\n");
        }
        
        contenido.append("Saludos,\n");
        contenido.append("Administración Mi Casita Segura");
        
        return contenido.toString();
    }

    // Método auxiliar para repetir caracteres (reemplazo de String.repeat)
    private String repetirCaracter(char c, int veces) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < veces; i++) {
            sb.append(c);
        }
        return sb.toString();
    }

    // Método para integración futura con servicios de email reales
    public void configurarServicioEmail(String provider, String apiKey, String fromEmail) {
        System.out.println("Configurando servicio de email: " + provider);
        // Aquí implementarías la integración con SendGrid, AWS SES, etc.
    }

    // Método para validar si el servicio está configurado
    public boolean isServicioEmailConfigurado() {
        return false; // Por ahora siempre falso, usar logs
    }

    // Método para obtener estadísticas de notificaciones
    public void mostrarEstadisticas() {
        System.out.println("Servicio de Notificaciones - Estado:");
        System.out.println("- Método activo: Registro en consola y archivo log");
        System.out.println("- Archivo de log: " + LOG_FILE);
        System.out.println("- Email externo: No configurado");
    }
}