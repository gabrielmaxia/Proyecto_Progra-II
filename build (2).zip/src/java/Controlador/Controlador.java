package Controlador;

import Modelo.Persona;
import ModeloDAO.PersonaDAO;
import Util.QRUtil;
import Util.EmailUtil;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Controlador extends HttpServlet {

    String Mantenimiento = "Vistas/Mantenimiento.jsp";
    String listar = "vistas/listar.jsp";
    String add = "vistas/add.jsp";
    String edit = "vistas/edit.jsp";
    Persona p = new Persona();
    PersonaDAO dao = new PersonaDAO();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");
        String acceso = listar;

        if (accion == null || accion.equals("listar")) {
            acceso = listar;
        } else if (accion.equals("add")) {
            acceso = add;
        } else if (accion.equals("Guardar usuario")) {
            // RN2: Validaciones de formato minimas + no vacios (lado servidor)
            String dpi = val(request.getParameter("txtDpi"));
            String nombres = val(request.getParameter("txtNombres"));
            String apellidos = val(request.getParameter("txtApellidos"));
            String correo = val(request.getParameter("txtCorreo"));
            String pass = val(request.getParameter("txtPassword"));
            String rol = val(request.getParameter("cbRol"));
            String lote = val(request.getParameter("cbLote"));
            Integer numeroCasa = parseIntOrNull(request.getParameter("cbNumeroCasa"));

            if (dpi.isEmpty() || nombres.isEmpty() || apellidos.isEmpty() || correo.isEmpty() || pass.isEmpty() || rol.isEmpty()) {
                request.setAttribute("error", "Todos los campos obligatorios deben estar llenos.");
                acceso = add;
            } else if (dao.existeDuplicado(dpi, correo)) {
                // FA3 - Usuario duplicado
                request.setAttribute("error", "El DPI o el correo ya están registrados.");
                acceso = add;
            } else {
                p = new Persona(0, dpi, nombres, apellidos, correo, pass, rol, lote, numeroCasa, true);
                boolean ok = dao.add(p);
                if (ok) {
                    try {
                        // RN3: Generar QR y enviar correo
                        String textoQR = "DPI:" + dpi + "|Nombre:" + nombres + " " + apellidos + "|Rol:" + rol;
                        byte[] qr = QRUtil.generateQRBytes(textoQR, 300);
                        String asunto = "Notificación de accesos creados";
                        String cuerpo = "¡Hola!\n\nSe ha generado exitosamente tu código QR de acceso al residencial. A continuación, encontrarás los detalles de tu registro:\n\n" +
                                "Nombre del Residente: " + nombres + " " + apellidos + "\n" +
                                "Validez del código QR: Permanente\n\n" +
                                "Instrucciones importantes:\n" +
                                "- Guarda este correo o el código QR adjunto.\n" +
                                "- Preséntalo al llegar al residencial para que el personal de seguridad lo escanee y valide tu acceso.";
                        try {
                            EmailUtil.sendEmailWithAttachment(correo, asunto, cuerpo, qr, "qr_acceso.png");
                            request.setAttribute("msg", "Usuario creado correctamente (QR enviado por correo).");
                        } catch (Exception mailEx) {
                            request.setAttribute("msg", "Usuario creado correctamente (No se pudo enviar el correo: " + mailEx.getMessage() + ").");
                        }
                    } catch (Exception ex) {
                        request.setAttribute("msg", "Usuario creado correctamente (No se pudo generar el QR: " + ex.getMessage() + ").");
                    }
                    acceso = listar;
                } else {
                    request.setAttribute("error", "No se pudo crear el usuario.");
                    acceso = add;
                }
            }
        } else if (accion.equals("eliminar")) {
            int id = Integer.parseInt(request.getParameter("id"));
            dao.eliminar(id);
            request.setAttribute("msg", "Usuario eliminado correctamente");
            acceso = listar;
        } else if (accion.equals("Actualizar")) {
            int id = Integer.parseInt(request.getParameter("txtId"));
            String dpi = val(request.getParameter("txtDpi"));
            String nombres = val(request.getParameter("txtNombres"));
            String apellidos = val(request.getParameter("txtApellidos"));
            String correo = val(request.getParameter("txtCorreo"));
            String pass = val(request.getParameter("txtPassword"));
            String rol = val(request.getParameter("cbRol"));
            String lote = val(request.getParameter("cbLote"));
            Integer numeroCasa = parseIntOrNull(request.getParameter("cbNumeroCasa"));
            Persona pe = new Persona(id, dpi, nombres, apellidos, correo, pass, rol, lote, numeroCasa, true);
            dao.edit(pe);
            request.setAttribute("msg", "Usuario actualizado.");
            acceso = listar;
        } else if (accion.equals("editar")) {
            request.setAttribute("idper", request.getParameter("id"));
            acceso = edit;
        }
        
        else if(accion.equalsIgnoreCase("login")){
    String usuario = request.getParameter("username");
    String clave = request.getParameter("password");

    PersonaDAO udao = new PersonaDAO ();
    boolean existe = udao.autenticar(usuario, clave);

    if(existe) {
        // Login correcto
        response.sendRedirect("Controlador?accion=Mantenimiento");
    } else {
        // Login incorrecto
        response.sendRedirect("login.jsp?error=1");
    }
    return;
}


        RequestDispatcher vista = request.getRequestDispatcher(acceso);
        vista.forward(request, response);
    }

    private static String val(String s) { return s == null ? "" : s.trim(); }
    private static Integer parseIntOrNull(String s) {
        try { return (s==null || s.trim().isEmpty()) ? null : Integer.parseInt(s.trim()); } catch (Exception e) { return null; }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Controlador CRUD de Persona (Mantenimiento de Usuarios)";
    }
}
