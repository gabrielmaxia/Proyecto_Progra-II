package ModeloDAO;

import Config.Conexion;
import Intefaces.CRUD;
import Modelo.Persona;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PersonaDAO implements CRUD {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    public List listar() {
        ArrayList<Persona> list = new ArrayList<>();
        String sql = "SELECT id, dpi, nombres, apellidos, correo, rol, lote, numero_casa, activo FROM persona WHERE activo = 1";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Persona p = new Persona();
                p.setId(rs.getInt(1));
                p.setDpi(rs.getString(2));
                p.setNombres(rs.getString(3));
                p.setApellidos(rs.getString(4));
                p.setCorreo(rs.getString(5));
                p.setRol(rs.getString(6));
                p.setLote(rs.getString(7));
                int n = rs.getInt(8);
                p.setNumeroCasa(rs.wasNull() ? null : n);
                p.setActivo(rs.getBoolean(9));
                list.add(p);
            }
        } catch (Exception e) {
            System.out.println("Error listar: " + e.getMessage());
        }
        return list;
    }

    public boolean existeDuplicado(String dpi, String correo) {
        String sql = "SELECT COUNT(*) FROM persona WHERE dpi = ? OR correo = ?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, dpi);
            ps.setString(2, correo);
            rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1) > 0;
        } catch (Exception e) {
            System.out.println("Error existeDuplicado: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean add(Persona p) {
        String sql = "INSERT INTO persona(dpi, nombres, apellidos, correo, password, rol, lote, numero_casa, activo) VALUES (?,?,?,?,?,?,?,?,1)";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, p.getDpi());
            ps.setString(2, p.getNombres());
            ps.setString(3, p.getApellidos());
            ps.setString(4, p.getCorreo());
            ps.setString(5, p.getPassword());
            ps.setString(6, p.getRol());
            ps.setString(7, p.getLote());
            if (p.getNumeroCasa() == null) ps.setNull(8, java.sql.Types.INTEGER);
            else ps.setInt(8, p.getNumeroCasa());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.out.println("Error add: " + e.getMessage());
        }
        return false;
    }

    @Override
    public Persona list(int id) {
        String sql = "SELECT id, dpi, nombres, apellidos, correo, password, rol, lote, numero_casa, activo FROM persona WHERE id = ?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                return new Persona(
                    rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
                    rs.getString(5), rs.getString(6), rs.getString(7),
                    rs.getString(8), (Integer) rs.getObject(9), rs.getBoolean(10)
                );
            }
        } catch (Exception e) {
            System.out.println("Error list(id): " + e.getMessage());
        }
        return null;
    }

    @Override
    public boolean edit(Persona p) {
        String sql = "UPDATE persona SET dpi=?, nombres=?, apellidos=?, correo=?, password=?, rol=?, lote=?, numero_casa=? WHERE id=?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, p.getDpi());
            ps.setString(2, p.getNombres());
            ps.setString(3, p.getApellidos());
            ps.setString(4, p.getCorreo());
            ps.setString(5, p.getPassword());
            ps.setString(6, p.getRol());
            ps.setString(7, p.getLote());
            if (p.getNumeroCasa() == null) ps.setNull(8, java.sql.Types.INTEGER);
            else ps.setInt(8, p.getNumeroCasa());
            ps.setInt(9, p.getId());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.out.println("Error edit: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean eliminar(int id) {
        String sql="delete from persona where Id="+id;
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
        }
        return false;
    }

    public boolean autenticar(String username, String password) {
        String sql = "SELECT * FROM usuarios WHERE username=? AND password=?";
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            rs=ps.executeQuery();
            return rs.next();
        } catch (Exception e) {
           e.printStackTrace();
           return false;
        }
    }
}
