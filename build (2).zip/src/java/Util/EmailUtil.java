package Util;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

public class EmailUtil {
    public static void sendEmailWithAttachment(String to, String subject, String body, byte[] attachment, String filename) throws Exception {
        // Configure according to your SMTP server (placeholders)
        final String username = System.getProperty("mail.user", "not-set");
        final String password = System.getProperty("mail.pass", "not-set");
        final String host = System.getProperty("mail.host", "smtp.gmail.com");
        final String port = System.getProperty("mail.port", "587");

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", port);

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(username));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
        message.setSubject(subject);

        // Body
        MimeBodyPart textPart = new MimeBodyPart();
        textPart.setText(body, "UTF-8");

        // Attachment
        MimeBodyPart attachPart = new MimeBodyPart();
        DataSource source = new ByteArrayDataSource(attachment, "image/png");
        attachPart.setDataHandler(new DataHandler(source));
        attachPart.setFileName(filename);

        Multipart multipart = new MimeMultipart();
        multipart.addBodyPart(textPart);
        multipart.addBodyPart(attachPart);

        message.setContent(multipart);

        Transport.send(message);
    }
}
