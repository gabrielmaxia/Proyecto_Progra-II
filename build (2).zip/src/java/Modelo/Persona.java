package Modelo;

public class Persona {
    private int id;
    private String dpi;
    private String nombres;
    private String apellidos;
    private String correo;
    private String password;
    private String rol; // Administrador de residencial, Agente de seguridad de residencial, Residente
    private String lote; // A-Z
    private Integer numeroCasa; // 1-50
    private boolean activo = true;

    public Persona() {}

    public Persona(int id, String dpi, String nombres, String apellidos, String correo, String password,
                   String rol, String lote, Integer numeroCasa, boolean activo) {
        this.id = id;
        this.dpi = dpi;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.correo = correo;
        this.password = password;
        this.rol = rol;
        this.lote = lote;
        this.numeroCasa = numeroCasa;
        this.activo = activo;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getDpi() { return dpi; }
    public void setDpi(String dpi) { this.dpi = dpi; }

    public String getNombres() { return nombres; }
    public void setNombres(String nombres) { this.nombres = nombres; }

    public String getApellidos() { return apellidos; }
    public void setApellidos(String apellidos) { this.apellidos = apellidos; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }

    public String getLote() { return lote; }
    public void setLote(String lote) { this.lote = lote; }

    public Integer getNumeroCasa() { return numeroCasa; }
    public void setNumeroCasa(Integer numeroCasa) { this.numeroCasa = numeroCasa; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }
}
