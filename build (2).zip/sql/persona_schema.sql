-- Esquema sugerido para 'persona' acorde al mantenimiento de usuarios
CREATE TABLE IF NOT EXISTS persona (
  id INT AUTO_INCREMENT PRIMARY KEY,
  dpi VARCHAR(13) NOT NULL UNIQUE,
  nombres VARCHAR(100) NOT NULL,
  apellidos VARCHAR(100) NOT NULL,
  correo VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  rol VARCHAR(60) NOT NULL,
  lote CHAR(1) NULL,
  numero_casa INT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1
);
