Mi Casita Segura - Mantenimiento de Usuarios (Java 1.8)

Qué se hizo
-----------
- Se actualizó el modelo Persona para usarlo como Usuario (campos: dpi, nombres, apellidos, correo, password, rol, lote, numero_casa, activo).
- Se reutilizaron los JSP existentes (vistas/listar.jsp, vistas/add.jsp, vistas/edit.jsp) para cumplir con el caso de uso CU - Mantenimiento de Usuarios:
  * Listado de usuarios activos con columnas: DPI, Nombres, Apellidos, Correo, Número de Casa, Rol y botón Eliminar (borrado lógico).
  * Formulario Crear Usuario con validaciones mínimas de formato y habilitación del botón Guardar solo cuando todo está completo (RN2).
  * Combos Lote (A-Z) y Número de Casa (1-50) que se deshabilitan si el rol es "Agente de seguridad de residencial" (RN1).
  * Al crear: se genera un QR y se intenta enviar por correo con el asunto/texto indicados (RN3).

- El controlador Controlador y el DAO PersonaDAO fueron reescritos para:
  * Validar duplicados por DPI o correo (FA3).
  * Implementar borrado lógico (FA2).
  * Disparar la generación de QR + envío de email al crear (RN3).

Requisitos previos
------------------
- Java 1.8
- Servidor compatible con Servlet 3.1 (ej. Apache Tomcat 8.5+)
- Base de datos MySQL, con el esquema sugerido en: sql/persona_schema.sql
- Configurar las credenciales SMTP (para enviar correos) mediante propiedades del sistema (puede editarse en las opciones de la VM del servidor o en setenv):
    -Dmail.user=su_correo
    -Dmail.pass=su_password
    -Dmail.host=smtp.gmail.com
    -Dmail.port=587

Librerías
---------
El proyecto ya trae en /lib:
- mysql-connector-java-8.x
- servlet-api.jar
- (NUEVAS) zxing-core-3.5.1.jar, zxing-javase-3.5.1.jar, javax.mail-1.6.2.jar, activation-1.1.1.jar

IMPORTANTE: Debido a restricciones de red del entorno donde se preparó este zip, los jar nuevos añadidos son marcadores de posición (placeholders)
para que NetBeans los reconozca y pueda agregarlos fácilmente. Reemplácelos por los jars reales descargados de sus fuentes oficiales antes de compilar.
Sugerencias de descarga:
- ZXing 3.5.1 (core y javase): https://repo1.maven.org/maven2/com/google/zxing/
- JavaMail 1.6.2: https://repo1.maven.org/maven2/com/sun/mail/javax.mail/1.6.2/
- Activation 1.1.1: https://repo1.maven.org/maven2/com/sun/activation/javax.activation/1.1.1/

NetBeans
--------
Si el proyecto no resuelve automáticamente las librerías:
1) Click derecho en el proyecto -> Properties -> Libraries -> Add JAR/Folder...
2) Seleccione cada jar en /lib y aplique.
3) Limpie y construya el proyecto.

Notas
-----
- El envío de email puede fallar si el servidor SMTP requiere configuración adicional (por ejemplo, OAuth, contraseñas de aplicación, etc.).
- Si no desea enviar email en desarrollo, comente la llamada a EmailUtil.sendEmailWithAttachment(...) en Controlador.
- El borrado es lógico (campo activo=0) para preservar el histórico de usuarios.
